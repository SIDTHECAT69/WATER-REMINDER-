# 💧 Water Reminder App

![Banner](https://i.postimg.cc/T3zx4G93/Screenshot-2025-06-13-at-1-22-53-AM.png)

> *Stay hydrated. Stay healthy. And let code remind you!*

## 🚀 Live Demo

🎥 **Watch it in action** – [YouTube Demo](https://youtu.be/3pvxIRXuXpc)

---

## 📖 About the Project

Ever got so lost in work or Netflix that you forgot to drink water?  
Been there. Done that. Dehydrated.

So here's a **fun and functional project** built with love and caffeine ☕ — a **Water Reminder App** that reminds you to drink water at regular intervals.

This isn’t just a project. It’s a digital health buddy. Built using just **HTML**, **CSS**, and **JavaScript**, this lightweight app runs on the browser and keeps nudging you gently to take a sip!

---

## 🛠️ Tech Stack

This project is built using:

- 🌐 **HTML5** – for the structure
- 🎨 **CSS3** – for styling the refreshingly clean UI
- ⚙️ **JavaScript** – for timer logic and alert popups

---

## ✨ Features

- ⏰ Customizable water reminder timer
- 🔔 Notification popups with sound (because silence is overrated)
- 🧠 Lightweight and beginner-friendly logic
- 📱 Responsive layout (drink water on desktop or mobile!)

---

## 🎯 How It Works

1. Open the app in any modern browser.
2. Set your preferred interval (e.g., every 30 minutes).
3. Let the timer run in the background.
4. Get reminded with a pop-up and sound.
5. Drink water like the hydrated champion you are! 🥇💦

---

## 🌈 Why This Project?

This project was built as a **fun mix of health + code**, and to demonstrate how you can build **real-world utility tools** with the basic web dev trio: HTML, CSS & JS.

Also — let’s be honest — sometimes coding for health is a great excuse to code more. 😉

---

## 📸 Sneak Peek

Here’s how the app looks in all its glory:

![Interface](https://i.postimg.cc/T3zx4G93/Screenshot-2025-06-13-at-1-22-53-AM.png)

---

## 👨‍💻 Created By

**🧠 Prince Thakur**  
Senior Coding Trainer | Front-End Enthusiast | Creative Developer  
> *“I don’t just teach code. I make code drink water.”*

🔗 [LinkedIn](https://www.linkedin.com/in/prince-thakur-/)  
📧 [p777thakur@gmail.com](mailto:p777thakur@gmail.com)

---

## 😄 Fun Fact

This project may not be AI-powered, but it **reminds you better than your gym trainer ever could.**  
It doesn't judge you for forgetting water. It simply *alerts*, *smiles*, and *saves your kidneys* one sip at a time.

---

## 🧪 Want to Contribute?

Have ideas to make it smarter? Add notifications? Sync with calendar?  
Fork it. Clone it. Play with it. And send a pull request!

---

## 🏷️ License

This project is open source under the MIT License.  
Because good hydration and good code should both be free.

---

Stay Hydrated, Stay Awesome! 🚰  

